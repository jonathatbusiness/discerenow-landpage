"use client";

import {
  CheckCircle2,
  FileText,
  MousePointerClick,
  Puzzle,
} from "lucide-react";

import { useI18n } from "@/providers/I18nProvider";

export default function AddinSection() {
  const { t } = useI18n();

  const icons = [FileText, Puzzle, MousePointerClick];

  return (
    <section
      id="addin"
      className="bg-[radial-gradient(circle_at_0%_0%,rgba(14,165,233,0.18),transparent_38%),radial-gradient(circle_at_100%_0%,rgba(236,72,153,0.18),transparent_40%),linear-gradient(180deg,#ffffff_0%,#f8fafc_100%)] py-20 text-dn-text"
    >
      <div className="mx-auto max-w-6xl px-6">
        <div className="grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-dn-blue">
              {t.addin.eyebrow}
            </p>

            <h2 className="mt-4 text-3xl font-bold md:text-4xl">
              {t.addin.title}
            </h2>

            <p className="mt-6 text-lg leading-relaxed text-dn-muted">
              {t.addin.description}
            </p>

            <ul className="mt-8 space-y-4">
              {t.addin.bullets.map((bullet) => (
                <li key={bullet} className="flex gap-3 text-sm text-dn-text">
                  <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-dn-blue" />
                  <span>{bullet}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="grid gap-5">
            {t.addin.cards.map((card, index) => {
              const Icon = icons[index] ?? Puzzle;

              return (
                <article
                  key={card.title}
                  className="rounded-3xl border border-dn-border bg-white p-6 shadow-dn-soft"
                >
                  <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-2xl bg-dn-bg text-white">
                    <Icon className="h-5 w-5" />
                  </div>

                  <h3 className="text-xl font-semibold">{card.title}</h3>

                  <p className="mt-3 text-sm leading-relaxed text-dn-muted">
                    {card.description}
                  </p>
                </article>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
